"""Generate a synthetic used-car marketplace dataset (reproducible, seed=42).

The data is SYNTHETIC. It is modelled on a typical Indian used-car retail
catalogue (brands, models, INR prices, depreciation, city effects) so the
project can be run end to end without downloading anything.

Run:  python scripts/generate_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED, N = 42, 6000
CURRENT_YEAR = 2025
DATA_END = pd.Timestamp("2025-12-31")

# brand, model, new price (INR lakh), popularity weight, {fuel: weight}
MODELS = [
    ("Maruti Suzuki", "Swift", 7.0, 9, {"Petrol": 8, "CNG": 2}),
    ("Maruti Suzuki", "Baleno", 8.0, 8, {"Petrol": 9, "CNG": 1}),
    ("Maruti Suzuki", "Dzire", 7.5, 7, {"Petrol": 6, "CNG": 4}),
    ("Maruti Suzuki", "Wagon R", 6.0, 7, {"Petrol": 6, "CNG": 4}),
    ("Maruti Suzuki", "Brezza", 10.0, 5, {"Petrol": 7, "Diesel": 3}),
    ("Maruti Suzuki", "Ertiga", 11.0, 5, {"Petrol": 6, "Diesel": 3, "CNG": 1}),
    ("Hyundai", "i20", 8.5, 6, {"Petrol": 8, "Diesel": 2}),
    ("Hyundai", "Creta", 14.0, 7, {"Petrol": 5, "Diesel": 5}),
    ("Hyundai", "Venue", 10.0, 5, {"Petrol": 6, "Diesel": 4}),
    ("Hyundai", "Verna", 12.0, 4, {"Petrol": 6, "Diesel": 4}),
    ("Hyundai", "Grand i10 Nios", 7.0, 4, {"Petrol": 8, "CNG": 2}),
    ("Tata", "Nexon", 11.0, 7, {"Petrol": 5, "Diesel": 4, "Electric": 1}),
    ("Tata", "Harrier", 17.0, 3, {"Diesel": 10}),
    ("Tata", "Punch", 8.0, 5, {"Petrol": 8, "CNG": 1, "Electric": 1}),
    ("Tata", "Altroz", 8.5, 3, {"Petrol": 6, "Diesel": 4}),
    ("Mahindra", "XUV700", 18.0, 4, {"Petrol": 3, "Diesel": 7}),
    ("Mahindra", "Scorpio", 15.0, 4, {"Diesel": 10}),
    ("Mahindra", "Thar", 15.0, 3, {"Petrol": 4, "Diesel": 6}),
    ("Mahindra", "XUV300", 10.5, 3, {"Petrol": 5, "Diesel": 5}),
    ("Honda", "City", 13.0, 5, {"Petrol": 7, "Diesel": 3}),
    ("Honda", "Amaze", 8.5, 3, {"Petrol": 7, "Diesel": 3}),
    ("Toyota", "Innova Crysta", 21.0, 4, {"Diesel": 9, "Petrol": 1}),
    ("Toyota", "Fortuner", 38.0, 2, {"Diesel": 10}),
    ("Toyota", "Glanza", 8.0, 2, {"Petrol": 9, "CNG": 1}),
    ("Kia", "Seltos", 14.0, 4, {"Petrol": 5, "Diesel": 5}),
    ("Kia", "Sonet", 10.0, 3, {"Petrol": 6, "Diesel": 4}),
    ("Kia", "Carens", 12.0, 2, {"Petrol": 5, "Diesel": 5}),
    ("Skoda", "Slavia", 12.0, 2, {"Petrol": 10}),
    ("Volkswagen", "Virtus", 12.0, 2, {"Petrol": 10}),
    ("Renault", "Kwid", 5.5, 3, {"Petrol": 10}),
    ("Renault", "Triber", 7.0, 2, {"Petrol": 10}),
    ("MG", "Hector", 17.0, 2, {"Petrol": 5, "Diesel": 5}),
]
# city: (listing weight, price factor, speed factor where >1 means slower sales)
CITIES = {
    "Delhi": (14, 0.98, 1.00), "Mumbai": (13, 1.04, 1.10), "Bengaluru": (14, 1.02, 0.85),
    "Hyderabad": (11, 1.00, 0.90), "Pune": (9, 1.01, 0.95), "Chennai": (8, 0.99, 1.00),
    "Gurugram": (11, 1.03, 0.95), "Kolkata": (7, 0.95, 1.20), "Ahmedabad": (6, 0.97, 1.05),
    "Jaipur": (7, 0.94, 1.15),
}
FUEL_F = {"Petrol": 1.0, "Diesel": 1.05, "CNG": 0.93, "Electric": 0.97}
OWNER_F = {"First": 1.0, "Second": 0.93, "Third": 0.86, "Fourth & Above": 0.80}
YEARS = np.arange(2013, 2026)
YEAR_W = np.array([1, 2, 3, 4, 6, 8, 10, 12, 14, 15, 13, 8, 4], float)


def pick(rng, weights):
    w = np.array(weights, float)
    return int(rng.choice(len(w), p=w / w.sum()))


def main():
    rng = np.random.default_rng(SEED)
    city_names = list(CITIES)
    rows = []
    for i in range(N):
        brand, model, new_lakh, _, fuels = MODELS[pick(rng, [m[3] for m in MODELS])]
        fuel = list(fuels)[pick(rng, list(fuels.values()))]
        year = int(rng.choice(YEARS, p=YEAR_W / YEAR_W.sum()))
        age = CURRENT_YEAR - year
        km = int(max(1500, max(age, 0.5) * rng.normal(11000, 3500) * (1.15 if fuel == "Diesel" else 1.0)))
        owner = ["First", "Second", "Third", "Fourth & Above"][pick(rng, [62, 28, 8, 2])]
        auto_p = 0.55 if new_lakh >= 15 else 0.3 if new_lakh >= 9 else 0.18
        trans = "Automatic" if rng.random() < auto_p else "Manual"
        city = city_names[pick(rng, [CITIES[c][0] for c in city_names])]
        _, pf, sf = CITIES[city]
        fair = (new_lakh * 100000 * (0.86 ** age) * FUEL_F[fuel] * OWNER_F[owner]
                * (1.06 if trans == "Automatic" else 1.0) * pf
                * np.clip(1 - 1.2e-6 * (km - age * 10000), 0.85, 1.12))
        overprice = float(np.exp(rng.normal(0, 0.07)))
        listing = max(60000, int(round(fair * 1.06 * overprice, -3)))
        listed = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 670)))
        p_sold = float(np.clip(0.78 - 1.6 * (overprice - 1), 0.25, 0.95))
        sold_price = sold_date = days = None
        status = "Unsold"
        if rng.random() < p_sold:
            base = 26 * sf * overprice ** 2 * (1 + 0.03 * age)
            d = int(np.clip(rng.gamma(2.0, base / 2), 3, 180))
            sd = listed + pd.Timedelta(days=d)
            if sd <= DATA_END:
                disc = float(np.clip(rng.normal(0.035 + 0.0006 * d, 0.015), 0.0, 0.2))
                sold_price = int(round(listing * (1 - disc), -3))
                days, sold_date, status = d, sd.date(), "Sold"
        rows.append(dict(
            listing_id=f"SP{100000 + i}", listed_date=listed.date(), city=city, brand=brand,
            model=model, year=year, fuel_type=fuel, transmission=trans, owner_type=owner,
            km_driven=km, listing_price=listing, sold_price=sold_price, days_to_sell=days,
            sold_date=sold_date, status=status))
    df = pd.DataFrame(rows)
    out = Path(__file__).resolve().parents[1] / "data" / "used_cars.csv"
    out.parent.mkdir(exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Wrote {len(df)} rows to {out}; sold = {(df.status == 'Sold').mean():.1%}")


if __name__ == "__main__":
    main()
