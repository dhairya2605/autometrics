"""v0 baseline: keyword/template matcher with no LLM.

It exists so the project has a measured starting point. It only understands a few
fixed phrasings; everything else returns None (counted as a failure in evaluation).
"""
import re

CITIES = ["Delhi", "Mumbai", "Bengaluru", "Hyderabad", "Pune", "Chennai", "Gurugram", "Kolkata", "Ahmedabad", "Jaipur"]
FUELS = ["Petrol", "Diesel", "CNG", "Electric"]


def baseline_sql(question: str):
    q = question.lower().strip().rstrip("?")
    fuel = next((f for f in FUELS if f.lower() in q), None)
    city = next((c for c in CITIES if c.lower() in q), None)

    if re.search(r"how many (listings|cars).*(in total|are there|total)", q) and not (fuel or city):
        return "SELECT COUNT(*) FROM cars"
    if "average listing price" in q and fuel:
        return f"SELECT AVG(listing_price) FROM cars WHERE fuel_type = '{fuel}'"
    if "which city" in q and "most listings" in q:
        return "SELECT city FROM cars GROUP BY city ORDER BY COUNT(*) DESC LIMIT 1"
    if "how many" in q and "sold" in q and city:
        return f"SELECT COUNT(*) FROM cars WHERE status = 'Sold' AND city = '{city}'"
    if "average days to sell" in q and "by fuel" in q:
        return "SELECT fuel_type, AVG(days_to_sell) FROM cars GROUP BY fuel_type"
    return None
