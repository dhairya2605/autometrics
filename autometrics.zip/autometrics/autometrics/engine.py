"""Ties it together: question -> SQL -> validate -> run on DuckDB -> answer."""
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

from .baseline import baseline_sql
from .db import connect, run_query
from .validator import UnsafeSQLError, validate_sql


@dataclass
class Answer:
    question: str
    sql: Optional[str] = None
    df: Optional[pd.DataFrame] = None
    error: Optional[str] = None
    explanation: Optional[str] = None
    attempts: int = 1
    trace: list = field(default_factory=list)


class Engine:
    """mode: 'llm' (needs ANTHROPIC_API_KEY) or 'baseline' (rule-based, no key)."""

    def __init__(self, mode: str = "llm", prompt_version: str = "v3", model: Optional[str] = None, llm=None, con=None):
        self.mode = mode
        self.prompt_version = prompt_version
        self.con = con or connect()
        self.llm = llm
        if mode == "llm" and self.llm is None:
            from .llm_sql import DEFAULT_MODEL, LLMSQL

            self.llm = LLMSQL(prompt_version, model or DEFAULT_MODEL)

    def _execute(self, sql: str):
        safe = validate_sql(sql)
        return safe, run_query(self.con, safe)

    def ask(self, question: str, explain: bool = False) -> Answer:
        ans = Answer(question=question)
        if self.mode == "baseline":
            sql = baseline_sql(question)
            if sql is None:
                ans.error = "Baseline cannot parse this question."
                return ans
        else:
            sql = self.llm.generate(question)
        ans.trace.append(sql)
        try:
            ans.sql, ans.df = self._execute(sql)
        except (UnsafeSQLError, Exception) as e:  # noqa: BLE001 - surface any DB error to the user/eval
            ans.error = f"{type(e).__name__}: {e}"
            if self.mode == "llm" and self.prompt_version == "v3" and not isinstance(e, UnsafeSQLError):
                ans.attempts = 2
                try:
                    fixed = self.llm.repair(question, sql, ans.error)
                    ans.trace.append(fixed)
                    ans.sql, ans.df = self._execute(fixed)
                    ans.error = None
                except (UnsafeSQLError, Exception) as e2:  # noqa: BLE001
                    ans.error = f"{type(e2).__name__}: {e2}"
        if explain and self.mode == "llm" and ans.df is not None:
            ans.explanation = self.llm.explain(question, ans.sql, ans.df.head(20).to_string(index=False))
        return ans
