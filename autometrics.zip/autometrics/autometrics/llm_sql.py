"""LLM-backed SQL generation using the Anthropic API."""
import os

from .prompts import EXPLAIN_SYSTEM, SYSTEM_PROMPTS
from .validator import clean_sql

DEFAULT_MODEL = os.getenv("AUTOMETRICS_MODEL", "claude-sonnet-4-6")


class LLMSQL:
    def __init__(self, prompt_version: str = "v3", model: str = DEFAULT_MODEL, client=None):
        if prompt_version not in SYSTEM_PROMPTS:
            raise ValueError(f"Unknown prompt version {prompt_version!r}")
        self.prompt_version = prompt_version
        self.model = model
        if client is None:
            import anthropic  # imported lazily so tests can run without a key

            client = anthropic.Anthropic()
        self.client = client

    def _call(self, system: str, messages: list, max_tokens: int = 600) -> str:
        resp = self.client.messages.create(
            model=self.model, max_tokens=max_tokens, temperature=0, system=system, messages=messages
        )
        return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")

    def generate(self, question: str) -> str:
        text = self._call(SYSTEM_PROMPTS[self.prompt_version], [{"role": "user", "content": question}])
        return clean_sql(text)

    def repair(self, question: str, bad_sql: str, error: str) -> str:
        """v3 only: give the model its failing SQL plus the error and ask for a fix."""
        msgs = [
            {"role": "user", "content": question},
            {"role": "assistant", "content": bad_sql},
            {"role": "user", "content": f"That query failed with this error:\n{error}\nReturn a corrected single SQL query only."},
        ]
        return clean_sql(self._call(SYSTEM_PROMPTS[self.prompt_version], msgs))

    def explain(self, question: str, sql: str, table_text: str) -> str:
        msg = f"Question: {question}\nSQL: {sql}\nResult:\n{table_text}"
        return self._call(EXPLAIN_SYSTEM, [{"role": "user", "content": msg}], max_tokens=150).strip()
