"""DuckDB access layer: loads the CSV into memory and locks the connection down."""
from pathlib import Path

import duckdb
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "used_cars.csv"


def connect(csv_path: Path = DATA_PATH) -> duckdb.DuckDBPyConnection:
    """Return an in-memory DuckDB connection with a `cars` table.

    External file access is switched off after loading, so generated SQL cannot
    read or write anything outside the in-memory table.
    """
    con = duckdb.connect(":memory:")
    con.execute(
        "CREATE TABLE cars AS SELECT * FROM read_csv_auto(?, header=true)", [str(csv_path)]
    )
    con.execute("SET enable_external_access=false")
    return con


def run_query(con: duckdb.DuckDBPyConnection, sql: str) -> pd.DataFrame:
    return con.execute(sql).fetchdf()
