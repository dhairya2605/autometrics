"""Safety checks applied to every generated SQL string before it is executed."""
import re

FORBIDDEN = re.compile(
    r"\b(insert|update|delete|drop|alter|create|attach|detach|copy|pragma|install|load|"
    r"export|import|call|set|truncate|replace|grant|revoke)\b",
    re.IGNORECASE,
)


class UnsafeSQLError(ValueError):
    pass


def clean_sql(sql: str) -> str:
    """Strip markdown fences, comments and a trailing semicolon."""
    sql = sql.strip()
    fence = re.search(r"```(?:sql)?\s*(.*?)```", sql, re.DOTALL | re.IGNORECASE)
    if fence:
        sql = fence.group(1).strip()
    sql = re.sub(r"--[^\n]*", "", sql)
    sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.DOTALL)
    return sql.strip().rstrip(";").strip()


def validate_sql(sql: str) -> str:
    """Return cleaned SQL if it is a single read-only SELECT/WITH query, else raise."""
    sql = clean_sql(sql)
    if not sql:
        raise UnsafeSQLError("Empty query.")
    if ";" in sql:
        raise UnsafeSQLError("Only a single statement is allowed.")
    if not re.match(r"^(select|with)\b", sql, re.IGNORECASE):
        raise UnsafeSQLError("Only SELECT queries are allowed.")
    # Ignore string literals when scanning for forbidden keywords.
    no_literals = re.sub(r"'[^']*'", "''", sql)
    bad = FORBIDDEN.search(no_literals)
    if bad:
        raise UnsafeSQLError(f"Forbidden keyword: {bad.group(1)}")
    return sql
