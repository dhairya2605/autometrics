"""Prompt versions for NL -> SQL. Each version is one iteration you can measure.

v1  schema only (naive)
v2  + business definitions and few-shot examples
v3  v2 + one self-repair retry when the SQL errors (see llm_sql.py)

The few-shot examples below are NOT among the evaluation questions (no leakage).
"""

SCHEMA = """Table `cars` (DuckDB, one row per listing, 6,000 rows, listings from 2024-01 to 2025-12):
  listing_id      VARCHAR   unique id
  listed_date     DATE      date the car was listed
  city            VARCHAR   Delhi, Mumbai, Bengaluru, Hyderabad, Pune, Chennai, Gurugram, Kolkata, Ahmedabad, Jaipur
  brand           VARCHAR   e.g. 'Maruti Suzuki', 'Hyundai', 'Tata', 'Mahindra', 'Honda', 'Toyota', 'Kia'
  model           VARCHAR   e.g. 'Swift', 'Creta', 'Nexon'
  year            INTEGER   manufacturing year (2013-2025)
  fuel_type       VARCHAR   'Petrol', 'Diesel', 'CNG', 'Electric'
  transmission    VARCHAR   'Manual', 'Automatic'
  owner_type      VARCHAR   'First', 'Second', 'Third', 'Fourth & Above'
  km_driven       INTEGER   odometer reading in km
  listing_price   BIGINT    asking price in INR
  sold_price      DOUBLE    final price in INR; NULL if not sold
  days_to_sell    DOUBLE    days from listing to sale; NULL if not sold
  sold_date       DATE      NULL if not sold
  status          VARCHAR   'Sold' or 'Unsold'
"""

V1_SYSTEM = (
    "You translate business questions into a single DuckDB SQL query over the table below. "
    "Return only the SQL.\n\n" + SCHEMA
)

RULES = """
Business definitions (follow exactly):
- "Sold" cars are rows with status = 'Sold'. sold_price, days_to_sell and sold_date are NULL for unsold rows.
- Sell-through rate = share of listings that were sold = COUNT(*) FILTER (WHERE status='Sold') / COUNT(*), as a percentage.
- Discount % (price drop) = (listing_price - sold_price) / listing_price * 100, for sold cars only.
- "Fastest selling" = lowest average days_to_sell. "Slowest" = highest.
- Car age = 2025 - year (2025 is the reference year).
- Always apply a minimum sample size when the question asks for one; otherwise do not add filters.
- Round percentages and averages to 2 decimals. Use median(...) for medians.
- Break ties deterministically (ORDER BY the metric, then the name).
- Return only the columns the question asks for (plus the metric when a name is returned).
- Output a single SELECT (or WITH ... SELECT). No explanations.
"""

FEWSHOT = """
Examples:
Q: How many diesel cars are listed in Pune?
SQL: SELECT COUNT(*) AS listings FROM cars WHERE fuel_type = 'Diesel' AND city = 'Pune'

Q: Which brand has the highest average listing price?
SQL: SELECT brand, ROUND(AVG(listing_price), 2) AS avg_listing_price FROM cars GROUP BY brand ORDER BY avg_listing_price DESC, brand LIMIT 1

Q: What share of Kia listings were sold?
SQL: SELECT ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'Sold') / COUNT(*), 2) AS sell_through_pct FROM cars WHERE brand = 'Kia'

Q: Average discount percent by transmission type?
SQL: SELECT transmission, ROUND(AVG((listing_price - sold_price) * 100.0 / listing_price), 2) AS avg_discount_pct FROM cars WHERE status = 'Sold' GROUP BY transmission ORDER BY transmission
"""

V2_SYSTEM = (
    "You translate business questions into a single DuckDB SQL query over the table below. "
    "Return only the SQL.\n\n" + SCHEMA + RULES + FEWSHOT
)

SYSTEM_PROMPTS = {"v1": V1_SYSTEM, "v2": V2_SYSTEM, "v3": V2_SYSTEM}

EXPLAIN_SYSTEM = (
    "You are a data analyst. Given a question, the SQL that was run, and the result table, "
    "write ONE plain-English sentence answering the question with the key number(s). "
    "Do not mention SQL. Do not add information that is not in the result."
)
