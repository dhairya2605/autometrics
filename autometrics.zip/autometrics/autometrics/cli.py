"""Command line: python -m autometrics.cli "Which city has the most listings?" """
import argparse
import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional at runtime
    pass

from .engine import Engine


def main():
    ap = argparse.ArgumentParser(description="Ask metric questions about used-car data in plain English.")
    ap.add_argument("question", nargs="?", help="Question to ask (omit for interactive mode)")
    ap.add_argument("--mode", choices=["llm", "baseline"], default="llm")
    ap.add_argument("--prompt", choices=["v1", "v2", "v3"], default="v3")
    ap.add_argument("--no-explain", action="store_true")
    args = ap.parse_args()

    if args.mode == "llm" and not os.getenv("ANTHROPIC_API_KEY"):
        raise SystemExit("Set ANTHROPIC_API_KEY (see .env.example) or use --mode baseline.")
    eng = Engine(mode=args.mode, prompt_version=args.prompt)

    def run(q):
        a = eng.ask(q, explain=not args.no_explain)
        print(f"\nSQL:\n{a.sql or a.trace[-1] if a.trace else '(none)'}\n")
        if a.error:
            print(f"Error: {a.error}")
            return
        print(a.df.to_string(index=False))
        if a.explanation:
            print(f"\n{a.explanation}")

    if args.question:
        run(args.question)
    else:
        print("AutoMetrics. Type a question, or 'quit'.")
        while True:
            q = input("\n> ").strip()
            if q.lower() in {"quit", "exit", ""}:
                break
            run(q)


if __name__ == "__main__":
    main()
