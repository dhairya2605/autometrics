import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "eval"))

from autometrics.db import connect, run_query  # noqa: E402
from autometrics.engine import Engine  # noqa: E402
from autometrics.validator import UnsafeSQLError, validate_sql  # noqa: E402
from run_eval import results_match  # noqa: E402

QUESTIONS = json.loads((ROOT / "eval" / "questions.json").read_text())


@pytest.fixture(scope="module")
def con():
    return connect()


@pytest.mark.parametrize("sql", [
    "DROP TABLE cars", "SELECT 1; DROP TABLE cars", "DELETE FROM cars",
    "UPDATE cars SET city='X'", "COPY cars TO 'x.csv'", "PRAGMA database_list",
    "INSERT INTO cars VALUES (1)", "",
])
def test_validator_blocks_unsafe(sql):
    with pytest.raises(UnsafeSQLError):
        validate_sql(sql)


def test_validator_allows_select_and_strips_fences():
    assert validate_sql("```sql\nSELECT COUNT(*) FROM cars;\n```") == "SELECT COUNT(*) FROM cars"
    assert validate_sql("WITH t AS (SELECT 1) SELECT * FROM t").startswith("WITH")
    assert validate_sql("SELECT * FROM cars WHERE city = 'Set Free'")  # keyword inside a literal is fine


def test_external_access_disabled(con):
    with pytest.raises(Exception):
        run_query(con, "SELECT * FROM read_csv_auto('/etc/passwd')")


def test_dataset_shape(con):
    df = run_query(con, "SELECT COUNT(*) n, COUNT(DISTINCT listing_id) u FROM cars")
    assert df.n[0] == 6000 and df.u[0] == 6000
    bad = run_query(con, "SELECT COUNT(*) FROM cars WHERE (status='Sold') <> (sold_price IS NOT NULL)")
    assert bad.iloc[0, 0] == 0


@pytest.mark.parametrize("q", QUESTIONS, ids=[q["id"] for q in QUESTIONS])
def test_gold_sql_runs_and_is_nonempty(con, q):
    df = run_query(con, validate_sql(q["gold_sql"]))
    assert len(df) > 0


def test_results_match_tolerance_and_extra_columns(con):
    gold = run_query(con, "SELECT city FROM cars GROUP BY city ORDER BY COUNT(*) DESC, city LIMIT 1")
    extra = run_query(con, "SELECT city, COUNT(*) n FROM cars GROUP BY city ORDER BY n DESC, city LIMIT 1")
    wrong = run_query(con, "SELECT city FROM cars GROUP BY city ORDER BY COUNT(*), city LIMIT 1")
    assert results_match(gold, extra)
    assert not results_match(gold, wrong)


class FakeLLM:
    """Stands in for the API: first answer is broken, repair returns the fix."""
    def __init__(self):
        self.calls = 0

    def generate(self, question):
        return "SELECT COUNT(*) FROM carz"

    def repair(self, question, bad_sql, error):
        self.calls += 1
        return "SELECT COUNT(*) FROM cars"

    def explain(self, *a):
        return "There are 6000 listings."


def test_engine_self_repair_path(con):
    eng = Engine(mode="llm", prompt_version="v3", llm=FakeLLM(), con=con)
    a = eng.ask("How many listings?", explain=True)
    assert a.error is None and a.attempts == 2 and int(a.df.iloc[0, 0]) == 6000
    assert a.explanation


def test_engine_v2_does_not_repair(con):
    eng = Engine(mode="llm", prompt_version="v2", llm=FakeLLM(), con=con)
    assert eng.ask("How many listings?").error is not None


def test_engine_blocks_unsafe_llm_output(con):
    llm = SimpleNamespace(generate=lambda q: "DROP TABLE cars", repair=None, explain=None)
    a = Engine(mode="llm", prompt_version="v3", llm=llm, con=con).ask("x")
    assert "UnsafeSQLError" in a.error
