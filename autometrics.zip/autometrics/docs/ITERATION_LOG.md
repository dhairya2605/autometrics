# Iteration log

Record every run here. Only write numbers you actually got from `python eval/run_eval.py`.
Copy the failures from the run output (or `results/*.json`) and say what you changed.

## v0: rule-based baseline (measured)
- Result: **5/20 (25%)**; easy 5/7, medium 0/6, hard 0/7.
- What broke: it only recognises 5 fixed phrasings. It cannot handle rates, rankings with a minimum
  sample, time grouping, medians or derived columns, which is where an LLM is needed.

## v1: schema-only prompt (fill in after running)
- Result: __/20
- What broke (list question IDs and why, e.g. wrong definition of discount, ties, sold vs listed):
-
- Fix applied in v2:

## v2: definitions + few-shot (fill in after running)
- Result: __/20
- What broke:
-
- Fix applied in v3:

## v3: self-repair retry (fill in after running)
- Result: __/20   Rescued by retry: __ questions
- Remaining failures and why:
-

## Takeaway (write this last, in your own words)
-
