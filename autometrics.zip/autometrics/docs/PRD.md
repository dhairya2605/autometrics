# PRD: AutoMetrics (AI metrics analyst for used-car data)

**Author:** Dhairya Arora   **Status:** v1 built   **Data:** synthetic (see README)

## 1. Problem
Product managers and business teams ask analysts the same metric questions again and again
(sell-through rate, days to sell, discount at sale, city and brand comparisons). Each one waits on an
analyst's queue, and different analysts define "sold", "discount" or "fastest" differently.

## 2. Users
| User | Need |
|---|---|
| Product manager | Quick, trustworthy answers to "how is X doing?" without writing SQL |
| Analyst | Fewer repetitive requests; a way to check the SQL behind an answer |

## 3. Solution
A tool that turns a plain-English question into read-only SQL, runs it, and returns the table, the
SQL, and a one-line explanation. Shared metric definitions live in one place (`prompts.py`).

## 4. Success metrics
| Metric | Definition | Target |
|---|---|---|
| Answer accuracy (primary) | % of the 20 eval questions whose result matches the answer key | beat baseline; aim 80%+ |
| Hard-question accuracy | same, hard questions only | track per iteration |
| Unsafe execution rate | generated SQL that is not read-only but runs | 0 |
| Self-repair rescue rate | queries that fail first and pass after the retry | track for v3 |

## 5. Scope
**In:** single-table analytics, read-only SQL, evaluation harness.
**Out:** joins across tables, charts, authentication, live warehouse connection, multi-turn chat.

## 6. Key decisions and trade-offs
- **Evaluate on results, not SQL text.** Two different queries can both be right.
- **Definitions in the prompt, not left to the model.** Ambiguity ("fastest", "discount") caused most
  wrong answers in early thinking; one shared definition block fixes it.
- **Read-only by construction.** Validator plus DuckDB with external access disabled.
- **Baseline first.** A keyword matcher scores 25% (5/20), which gives the LLM versions something to beat.

## 7. Risks
- Wrong answer that looks confident -> always show the SQL next to the result.
- Metric definitions drift from the company's real ones -> definitions are one reviewed file.
- Small test set -> grow the question set from real user questions once in use.

## 8. Next steps
Add a feedback thumbs up/down log, expand to 100 questions from real usage, add multi-table joins.
