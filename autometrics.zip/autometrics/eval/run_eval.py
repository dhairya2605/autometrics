"""Evaluate a system against the gold answers.

Usage:
  python eval/run_eval.py --mode baseline
  python eval/run_eval.py --mode llm --prompt v1
  python eval/run_eval.py --mode llm --prompt v2
  python eval/run_eval.py --mode llm --prompt v3
  python eval/run_eval.py --mode oracle          # harness self-check: must score 100%

A question passes when the system's result contains every value of the gold result
(numbers within 1% tolerance, text case-insensitive), has the same number of rows,
and has no more than 3x the gold cell count (extra columns are tolerated).
Each run is saved to results/<mode>_<prompt>.json and a failure table is printed.
"""
import argparse
import json
import math
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:
    pass

from autometrics.db import connect, run_query  # noqa: E402
from autometrics.engine import Engine  # noqa: E402


def _cells(df):
    out = []
    for row in df.itertuples(index=False):
        for v in row:
            if v is None or (isinstance(v, float) and math.isnan(v)):
                out.append(None)
            elif isinstance(v, bool):
                out.append(str(v).lower())
            elif isinstance(v, (int, float)):
                out.append(float(v))
            else:
                out.append(str(v).strip().lower())
    return out


def _match(a, b):
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, float) and isinstance(b, float):
        return abs(a - b) <= max(0.011, 0.01 * abs(a))
    return a == b


def results_match(gold_df, ans_df) -> bool:
    if ans_df is None or len(gold_df) != len(ans_df):
        return False
    g, a = _cells(gold_df), _cells(ans_df)
    if len(a) > 3 * len(g):
        return False
    pool = list(a)
    for gv in g:
        for i, av in enumerate(pool):
            if _match(gv, av):
                pool.pop(i)
                break
        else:
            return False
    return True


def run(mode, prompt, limit=None):
    con = connect()
    questions = json.loads((ROOT / "eval" / "questions.json").read_text())[:limit]
    eng = None if mode == "oracle" else Engine(mode=mode, prompt_version=prompt, con=con)
    rows, passed = [], 0
    for q in questions:
        gold = run_query(con, q["gold_sql"])
        if mode == "oracle":
            sql, ans_df, err, attempts = q["gold_sql"], run_query(con, q["gold_sql"]), None, 1
        else:
            a = eng.ask(q["question"])
            sql, ans_df, err, attempts = a.sql or (a.trace[-1] if a.trace else None), a.df, a.error, a.attempts
        ok = results_match(gold, ans_df)
        passed += ok
        reason = "" if ok else (err or ("wrong result" if ans_df is not None else "no answer"))
        rows.append(dict(id=q["id"], difficulty=q["difficulty"], type=q["type"], question=q["question"],
                         passed=ok, reason=reason, attempts=attempts, system_sql=sql, gold_sql=q["gold_sql"]))
    acc = passed / len(questions)
    name = f"{mode}_{prompt}" if mode == "llm" else mode
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / f"{name}.json").write_text(json.dumps(dict(
        run=name, accuracy=round(acc, 4), passed=passed, total=len(questions), rows=rows), indent=2))
    print(f"\nRun: {name}   Accuracy: {passed}/{len(questions)} = {acc:.0%}")
    for d in ("easy", "medium", "hard"):
        sub = [r for r in rows if r["difficulty"] == d]
        if sub:
            print(f"  {d:<7}{sum(r['passed'] for r in sub)}/{len(sub)}")
    fails = [r for r in rows if not r["passed"]]
    if fails:
        print("\nFailures:")
        for r in fails:
            print(f"  {r['id']} [{r['difficulty']}] {r['reason'][:90]}\n      {r['question']}")
    return acc


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["baseline", "llm", "oracle"], default="baseline")
    ap.add_argument("--prompt", choices=["v1", "v2", "v3"], default="v3")
    ap.add_argument("--limit", type=int)
    args = ap.parse_args()
    if args.mode == "llm" and not os.getenv("ANTHROPIC_API_KEY"):
        raise SystemExit("Set ANTHROPIC_API_KEY first (see .env.example).")
    run(args.mode, args.prompt, args.limit)
